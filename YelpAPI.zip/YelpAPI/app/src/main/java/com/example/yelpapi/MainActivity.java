package com.example.yelpapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.commons.io.IOUtil;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.*;

public class MainActivity extends AppCompatActivity {

    private TextView tvSearchResult;
    private String API_KEY = "88RR4WnZJtAJeY_z4UA6bR-NhnlmhFk5zYFqxD30lDTrpfa543apNhHmDzum2ElLWI4od6pGjBfMjIoG7T9ReRU8vYaQejY57KwBwKwoj-r9ID9ahOJG4D1d5TRDYnYx";
    private List<String> ids = new ArrayList<>();
    private ArrayList<String> abc = new ArrayList<>();
    public EditText edtAddress;
    public Button btnSubmit;
    public String address = "14 Park Dr Boston";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSearchResult = (TextView) findViewById(R.id.tvSearchResult);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        edtAddress = (EditText) findViewById(R.id.edtAddress);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                address = edtAddress.getText().toString();
                new YelpService().execute();
            }
        });

        new YelpService().execute();
    }

    private class YelpService extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String url_formatted = String.format("https://api.yelp.com/v3/businesses/search?term=restaurants&location=%s", address);
            Log.i("MY LOG: [CHECKPOINT]", url_formatted);
            URL url = null;
            HttpURLConnection urlConnection = null;
            String responseString = null;
            try {
                url = new URL(url_formatted);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Authorization", "Bearer " + API_KEY);
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                responseString = IOUtil.toString(in);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return responseString;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.i("API RESPONSE:", result);
            JSONObject jsonObj = null;
            try {
                jsonObj = new JSONObject(result);
                if (jsonObj != null) {
                    JSONArray jsonArray_businesses = jsonObj.getJSONArray("businesses");
                    for (int i=0; i < jsonArray_businesses.length(); i++) {
                        /*ids.add(jsonArray_businesses.getJSONObject(i).getString("id"));*/
                        abc.add(jsonArray_businesses.getJSONObject(i).getString("name"));
                    }
                }
                new YelpBusinessDetailAPI().execute();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class YelpBusinessDetailAPI extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            String url_formatted = String.format("https://api.yelp.com/v3/businesses/%s",ids.get(0));
            URL url = null;
            HttpURLConnection urlConnection = null;
            String responseString = null;
            try {
                url = new URL(url_formatted);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestProperty("Authorization", "Bearer " + API_KEY);
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                responseString = IOUtil.toString(in);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return responseString;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObj = null;
            try {
                jsonObj = new JSONObject(s);
                if (jsonObj != null) {
                    /*String id = jsonObj.getString("id");
                    String name = jsonObj.getString("name");
                    String phone = jsonObj.getString("phone");
                    String review_count = jsonObj.getString("review_count");
                    String tvDisplay = String.format("id:%s\nname:%s\nphone:%s\nreview_count:%s", id,name,phone,review_count);
                    tvSearchResult.setText(tvDisplay);*/
                    tvSearchResult.setText(abc.toString());

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
