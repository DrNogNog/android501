package com.example.w5_p1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private GestureDetectorCompat mGestureDetector;
    private TextView textView;
    private ImageView imageView;
    private int[] imgResources = {  R.drawable.img1, R.drawable.img2,
                                    R.drawable.img3, R.drawable.img4,
                                    R.drawable.img5, R.drawable.img6,
                                    R.drawable.img7, R.drawable.img8,
                                    R.drawable.img9, R.drawable.img10};
    private int imgIndex = 0;
    private int imgIndexMax = 9;
    private float scrollStartX1 = 0;
    private float scrollStartY1 = 0;

    private float acceleration;
    private float currAcceleration;
    private float lastAcceleration;

    private float FLING_DIST_THRESHOLD = 200;
    private float FLING_VELO_THRESHOLD = 500;
    private float SCROLL_DIST_THRESHOLD = 200;
    private float HARDSHAKE_THRESHOLD = 10000;

    Animation slideoff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGestureDetector = new GestureDetectorCompat(this, new GestureListener());
        textView = (TextView) findViewById(R.id.textView);
        imageView = (ImageView) findViewById(R.id.imageView);

        // init acceleration values
        acceleration = 0.00f;
        currAcceleration = SensorManager.GRAVITY_EARTH;
        lastAcceleration = SensorManager.GRAVITY_EARTH;

        // animation
        slideoff = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slideoff);
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float diffX = e2.getX() - e1.getX();
            float diffY = e2.getY() - e1.getY();
            if (Math.abs(diffX) > Math.abs(diffY)) {        // left or right fling
                if (Math.abs(diffX) > FLING_DIST_THRESHOLD && Math.abs(velocityX) > FLING_VELO_THRESHOLD) {
                    if (diffX > 0) {onFlingRight();}
                    else {onFlingLeft();}
                }
            }
            return super.onFling(e1, e2, velocityX, velocityY);
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
//            System.out.println("e1 [ X = " + e1.getX() + ", Y = " + e1.getY() + " ]");
//            System.out.println("e2 [ X = " + e2.getX() + ", Y = " + e2.getY() + " ]");
            float diffX = e2.getX() - e1.getX();
            float diffY = e2.getY() - e1.getY();

            if (Math.abs(diffX) > SCROLL_DIST_THRESHOLD) {
                if (e1.getX() != scrollStartX1 || e1.getY() != scrollStartY1) {
                    scrollStartX1 = e1.getX();
                    scrollStartY1 = e1.getY();
                    if (diffX > 0) {onScrollRight();}
                    else if (diffX < 0) {onScrollLeft();}
                }
            }

            return super.onScroll(e1, e2, distanceX, distanceY);
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
            imageView.startAnimation(slideoff);
            imgIndex++;
            setImageView(imgIndex);
            return super.onDoubleTap(e);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mGestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    private void onScrollRight() {
        imgIndex--;
        setImageView(imgIndex);
        System.out.println("scroll right");
    }

    private void onScrollLeft() {
        imgIndex++;
        setImageView(imgIndex);
        System.out.println("scroll left");
    }

    private void onFlingRight() {
        imgIndex -= 2;
        setImageView(imgIndex);
        System.out.println("fling right");
    }

    private void onFlingLeft() {
        imgIndex += 2;
        setImageView(imgIndex);
        System.out.println("fling left");
    }

    private void setImageView(int index) {
        if (index > imgIndexMax) {
            index = index - imgIndexMax -1;
            imgIndex = index;
        }
        if (index < 0) {
            index = index + imgIndexMax +1;
            imgIndex = index;
        }
        imageView.setImageResource(imgResources[index]);
        int textIndex = index +1;
        textView.setText("IMAGE " + textIndex);
    }

    @Override
    protected void onStart() {
        super.onStart();
        enableAccelerometerListening();
    }

    @Override
    protected void onStop() {
        disableAccelerometerListening();
        super.onStop();
    }

    private void enableAccelerometerListening() {
        SensorManager sensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
        sensorManager.registerListener(sensorEventListner,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void disableAccelerometerListening() {
        SensorManager sensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
        sensorManager.unregisterListener(sensorEventListner,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
    }

    private final SensorEventListener sensorEventListner = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float x = sensorEvent.values[0];
            float y = sensorEvent.values[1];
            float z = sensorEvent.values[2];

            lastAcceleration = currAcceleration;
            currAcceleration = x * x + y * y + z * z;
            acceleration = currAcceleration * (currAcceleration - lastAcceleration);

            if (acceleration > HARDSHAKE_THRESHOLD) {
                imgIndex--;
                setImageView(imgIndex);
                System.out.println("hard shake");
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };
}