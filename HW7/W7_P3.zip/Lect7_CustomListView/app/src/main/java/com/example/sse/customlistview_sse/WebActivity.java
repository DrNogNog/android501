package com.example.sse.customlistview_sse;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class WebActivity extends AppCompatActivity {
    private TextView tvTitle;
    private WebView wvWebpage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webpage);
        Bundle extras = getIntent().getExtras();
        String title = extras.getString("episodeTitle");
        String episodes[] = getResources().getStringArray(R.array.episodes);

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        wvWebpage = (WebView) findViewById(R.id.wvWebpage);
        VideoView vvView = (VideoView) findViewById(R.id.vvVideo);
        vvView.setVisibility(View.INVISIBLE);

        String url = "http://www.google.com/";
        if (title.equals(episodes[0])) url = "https://www.imdb.com/title/tt0708449/";
        if (title.equals(episodes[1])) url = "https://www.imdb.com/title/tt0708418/";
        if (title.equals(episodes[2])) url = "https://www.imdb.com/title/tt0708483/";
        if (title.equals(episodes[3])) url = "https://www.imdb.com/title/tt0708438/";
        if (title.equals(episodes[4])) url = "https://www.imdb.com/title/tt0708443/";
        if (title.equals(episodes[5])) url = "https://www.imdb.com/title/tt0708473/";
        if (title.equals(episodes[6])) url = "https://www.imdb.com/title/tt0708480/";
        if (title.equals(episodes[7])) url = "http://shop.startrek.com";
        if (title.equals(episodes[8])){
            Intent i = new Intent(Intent.ACTION_DIAL);
            i.setData(Uri.parse("tel:1800startrk"));
            startActivity(i);
        }
        else if (title.equals(episodes[9])){
            Uri uri = Uri.parse("smsto:1234567");
            Intent i = new Intent(Intent.ACTION_SENDTO, uri);
            i.putExtra("sms_body", "Ouch!");
            startActivity(i);
        }
        else if (title.equals(episodes[10])) {
            MediaPlayer mediaPlayer = MediaPlayer.create(WebActivity.this, R.raw.llap);
            mediaPlayer.start();
        }
        else if (title.equals(episodes[11])) {
            vvView.setVisibility(View.VISIBLE);
            vvView.setVideoPath("android.resource://" + getPackageName() + "/" + R.raw.khan);

            MediaController mediaController = new MediaController(WebActivity.this);
            mediaController.setAnchorView(vvView);
            vvView.setMediaController(mediaController);
            vvView.start();
        }
        else {
            wvWebpage.loadUrl(url);
        }
        tvTitle.setText(title);
    }
}
