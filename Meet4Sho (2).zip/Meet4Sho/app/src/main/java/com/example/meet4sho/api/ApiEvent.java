package com.example.meet4sho.api;

public class ApiEvent {
}
